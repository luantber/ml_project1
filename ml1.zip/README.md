# Introduction



# Clustering Methods
## Kmeans 

## Dbscan

# Evaluation Metrics
## Distortion
## Error SSRE

# Dataset 1

## Loading Data
## Split Train/Test
## Choosing the best K 
### Kmeans Results
### DBScan REsults 

## Test Evaluation


# Dataset 2

## Loading Data
## Split Train/Test
## Choosing the best K 
### Kmeans Results
### DBScan REsults 

## Test Evaluation





